#include "player.h"

#include "world.h"
constexpr double walk_acceleration = 10;
constexpr double terminal_velocity = 300;
constexpr double jump_velocity = 25;
constexpr double gravity = 10;

Player::Player(const Vec<double>& position, const Vec<int>& size)
    : position{position}, size{size} {
    acceleration.y = gravity;
}

void Player::handle_input(const SDL_Event& event) {
    if (event.type == SDL_KEYDOWN) {
        SDL_Keycode key = event.key.keysym.sym;
        if (key == SDLK_RIGHT) {
            acceleration.x = walk_acceleration;
        } else if (key == SDLK_LEFT) {
            acceleration.x = -walk_acceleration;
        } else if (key == SDLK_SPACE) {
            velocity.y = -jump_velocity;
        }
    }
    if (event.type == SDL_KEYUP) {
        SDL_Keycode key = event.key.keysym.sym;
        if (key == SDLK_RIGHT) {
            acceleration.x = 0;
        } else if (key == SDLK_LEFT) {
            acceleration.x = 0;
        }
    }
}

void Player::update(World& world, double dt) {
    // make copy of physics components
    Vec<double> ftr_vel = velocity;
    Vec<double> ftr_acc = acceleration;
    Vec<double> ftr_pos = position;
    // update physics, semi-implicit euler
    ftr_vel += acceleration * dt;
    ftr_pos += ftr_vel * dt;
    SDL_Rect future{static_cast<int>(ftr_pos.x), static_cast<int>(ftr_pos.y),
                    size.x, size.y};
    if (world.has_any_intersections(future)) {
        // collided
        acceleration = {0, 0};
        velocity = {0, 0};
    } else {
        acceleration = ftr_acc;
        velocity = ftr_vel;
        position = ftr_pos;
    }
}

std::pair<SDL_Rect, Color> Player::get_sprite() const {
    int x = static_cast<int>(position, x);  // round down
    int y = static_cast<int>(position.y);
    SDL_Rect bounding_box{x, y, size.x, size.y};
    return {bounding_box, {255, 0, 255, 255}};
}
